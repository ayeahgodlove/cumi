--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.4
-- Dumped by pg_dump version 14.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cumi_db;
--
-- Name: cumi_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE cumi_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE cumi_db OWNER TO postgres;

\connect cumi_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_posts_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_posts_status AS ENUM (
    'DRAFT',
    'PUBLISHED',
    'REJECTED'
);


ALTER TYPE public.enum_posts_status OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: banners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banners (
    id character varying(10) NOT NULL,
    title character varying(500) NOT NULL,
    "subTitle" character varying(1000) NOT NULL,
    image character varying(500) NOT NULL,
    slug character varying(500) NOT NULL,
    "userId" character varying(10) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.banners OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    slug character varying(500) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courses (
    id character varying(10) NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(500) NOT NULL,
    description text NOT NULL,
    "imageUrl" character varying(500) NOT NULL,
    "userId" character varying(10) NOT NULL,
    "categoryId" character varying(10) NOT NULL,
    "authorName" character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.courses OWNER TO postgres;

--
-- Name: enrollments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.enrollments (
    id character varying(10) NOT NULL,
    "userId" character varying(10) NOT NULL,
    "courseId" character varying(10) NOT NULL,
    "enrollmentDate" timestamp with time zone,
    "completionDate" timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.enrollments OWNER TO postgres;

--
-- Name: event_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_tags (
    id integer NOT NULL,
    "tagId" character varying(10) NOT NULL,
    "eventId" character varying(10) NOT NULL
);


ALTER TABLE public.event_tags OWNER TO postgres;

--
-- Name: event_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_tags_id_seq OWNER TO postgres;

--
-- Name: event_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.event_tags_id_seq OWNED BY public.event_tags.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    id character varying(10) NOT NULL,
    title character varying(500) NOT NULL,
    description character varying(1000) NOT NULL,
    "imageUrl" character varying(500) NOT NULL,
    "userId" character varying(10) NOT NULL,
    "eventDate" timestamp with time zone NOT NULL,
    location character varying(500) NOT NULL,
    slug character varying(500) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.knex_migrations OWNER TO postgres;

--
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knex_migrations_id_seq OWNER TO postgres;

--
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.knex_migrations_lock OWNER TO postgres;

--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.knex_migrations_lock_index_seq OWNER TO postgres;

--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- Name: lessons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lessons (
    id character varying(10) NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(500) NOT NULL,
    description text NOT NULL,
    content text NOT NULL,
    "imageUrl" character varying(500) NOT NULL,
    "userId" character varying(10) NOT NULL,
    "courseId" character varying(10) NOT NULL,
    "authorName" character varying(255) NOT NULL,
    duration integer NOT NULL,
    difficulty character varying(128) NOT NULL,
    url character varying(255) NOT NULL,
    prerequisites text[] NOT NULL,
    objectives text[] NOT NULL,
    keywords text[] NOT NULL,
    author character varying(128) NOT NULL,
    reviews text[],
    language character varying(128),
    rating integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lessons OWNER TO postgres;

--
-- Name: media_tbl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_tbl (
    id character varying(10) NOT NULL,
    title character varying(500) NOT NULL,
    "imageUrl" character varying(500) NOT NULL,
    slug character varying(500) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.media_tbl OWNER TO postgres;

--
-- Name: opportunities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opportunities (
    id character varying(10) NOT NULL,
    title character varying(1000) NOT NULL,
    opp_type text NOT NULL,
    description text NOT NULL,
    requirements text NOT NULL,
    deadline date,
    location character varying(255) NOT NULL,
    "companyOrInstitution" character varying(500) NOT NULL,
    "contactEmail" character varying(255) NOT NULL,
    "applicationLink" character varying(255) NOT NULL,
    "isActive" boolean DEFAULT false,
    slug character varying(500) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT opportunities_opp_type_check CHECK ((opp_type = ANY (ARRAY['job'::text, 'scholarships'::text])))
);


ALTER TABLE public.opportunities OWNER TO postgres;

--
-- Name: COLUMN opportunities.opp_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.opportunities.opp_type IS 'Defines if the opportunity is a job or a scholarship';


--
-- Name: COLUMN opportunities.requirements; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.opportunities.requirements IS 'Requirements or qualifications for the job or scholarship';


--
-- Name: COLUMN opportunities.deadline; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.opportunities.deadline IS 'Deadline for the application';


--
-- Name: post_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.post_tags (
    id integer NOT NULL,
    "tagId" character varying(10) NOT NULL,
    "postId" character varying(10) NOT NULL
);


ALTER TABLE public.post_tags OWNER TO postgres;

--
-- Name: post_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.post_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_tags_id_seq OWNER TO postgres;

--
-- Name: post_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.post_tags_id_seq OWNED BY public.post_tags.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    id character varying(10) NOT NULL,
    title character varying(500) NOT NULL,
    description character varying(1000) NOT NULL,
    content text NOT NULL,
    "authorId" character varying(10) NOT NULL,
    "imageUrl" character varying(500) NOT NULL,
    slug character varying(500) NOT NULL,
    status text NOT NULL,
    "categoryId" character varying(10) NOT NULL,
    published_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT posts_status_check CHECK ((status = ANY (ARRAY['DRAFT'::text, 'PUBLISHED'::text, 'REJECTED'::text])))
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id character varying(10) NOT NULL,
    title character varying(500) NOT NULL,
    description character varying(1000) NOT NULL,
    "imageUrl" character varying(500) NOT NULL,
    "githubUrl" character varying(255) NOT NULL,
    "deployUrl" character varying(255) NOT NULL,
    "userId" character varying(10) NOT NULL,
    slug character varying(500) NOT NULL,
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: quizes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quizes (
    id character varying(10) NOT NULL,
    question character varying(500) NOT NULL,
    answers text[] NOT NULL,
    slug character varying(500) NOT NULL,
    "lessonId" character varying(10) NOT NULL,
    "correctAnswerIndex" integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.quizes OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    slug character varying(500) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id character varying(10) NOT NULL,
    title character varying(500) NOT NULL,
    description character varying(1000) NOT NULL,
    "imageUrl" character varying(500) NOT NULL,
    "userId" character varying(10) NOT NULL,
    slug character varying(500) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tags (
    id character varying(10) NOT NULL,
    name character varying(50) NOT NULL,
    slug character varying(500) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.tags OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    "userId" character varying(10) NOT NULL,
    "roleId" character varying(10) NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying(10) NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(50) NOT NULL,
    fullname character varying(150),
    password character varying(255) NOT NULL,
    "authStrategy" character varying(50) NOT NULL,
    address character varying(255) NOT NULL,
    verified boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: event_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_tags ALTER COLUMN id SET DEFAULT nextval('public.event_tags_id_seq'::regclass);


--
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- Name: post_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_tags ALTER COLUMN id SET DEFAULT nextval('public.post_tags_id_seq'::regclass);


--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banners (id, title, "subTitle", image, slug, "userId", created_at, updated_at) FROM stdin;
\.
COPY public.banners (id, title, "subTitle", image, slug, "userId", created_at, updated_at) FROM '$$PATH$$/3541.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, slug, created_at, updated_at) FROM stdin;
\.
COPY public.categories (id, name, slug, created_at, updated_at) FROM '$$PATH$$/3540.dat';

--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courses (id, title, slug, description, "imageUrl", "userId", "categoryId", "authorName", created_at, updated_at) FROM stdin;
\.
COPY public.courses (id, title, slug, description, "imageUrl", "userId", "categoryId", "authorName", created_at, updated_at) FROM '$$PATH$$/3554.dat';

--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.enrollments (id, "userId", "courseId", "enrollmentDate", "completionDate", created_at, updated_at) FROM stdin;
\.
COPY public.enrollments (id, "userId", "courseId", "enrollmentDate", "completionDate", created_at, updated_at) FROM '$$PATH$$/3557.dat';

--
-- Data for Name: event_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_tags (id, "tagId", "eventId") FROM stdin;
\.
COPY public.event_tags (id, "tagId", "eventId") FROM '$$PATH$$/3551.dat';

--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (id, title, description, "imageUrl", "userId", "eventDate", location, slug, created_at, updated_at) FROM stdin;
\.
COPY public.events (id, title, description, "imageUrl", "userId", "eventDate", location, slug, created_at, updated_at) FROM '$$PATH$$/3545.dat';

--
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
\.
COPY public.knex_migrations (id, name, batch, migration_time) FROM '$$PATH$$/3535.dat';

--
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
\.
COPY public.knex_migrations_lock (index, is_locked) FROM '$$PATH$$/3537.dat';

--
-- Data for Name: lessons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lessons (id, title, slug, description, content, "imageUrl", "userId", "courseId", "authorName", duration, difficulty, url, prerequisites, objectives, keywords, author, reviews, language, rating, created_at, updated_at) FROM stdin;
\.
COPY public.lessons (id, title, slug, description, content, "imageUrl", "userId", "courseId", "authorName", duration, difficulty, url, prerequisites, objectives, keywords, author, reviews, language, rating, created_at, updated_at) FROM '$$PATH$$/3555.dat';

--
-- Data for Name: media_tbl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_tbl (id, title, "imageUrl", slug, created_at, updated_at) FROM stdin;
\.
COPY public.media_tbl (id, title, "imageUrl", slug, created_at, updated_at) FROM '$$PATH$$/3552.dat';

--
-- Data for Name: opportunities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opportunities (id, title, opp_type, description, requirements, deadline, location, "companyOrInstitution", "contactEmail", "applicationLink", "isActive", slug, created_at, updated_at) FROM stdin;
\.
COPY public.opportunities (id, title, opp_type, description, requirements, deadline, location, "companyOrInstitution", "contactEmail", "applicationLink", "isActive", slug, created_at, updated_at) FROM '$$PATH$$/3553.dat';

--
-- Data for Name: post_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.post_tags (id, "tagId", "postId") FROM stdin;
\.
COPY public.post_tags (id, "tagId", "postId") FROM '$$PATH$$/3549.dat';

--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, title, description, content, "authorId", "imageUrl", slug, status, "categoryId", published_at, created_at, updated_at) FROM stdin;
\.
COPY public.posts (id, title, description, content, "authorId", "imageUrl", slug, status, "categoryId", published_at, created_at, updated_at) FROM '$$PATH$$/3542.dat';

--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, title, description, "imageUrl", "githubUrl", "deployUrl", "userId", slug, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.projects (id, title, description, "imageUrl", "githubUrl", "deployUrl", "userId", slug, "createdAt", "updatedAt") FROM '$$PATH$$/3543.dat';

--
-- Data for Name: quizes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quizes (id, question, answers, slug, "lessonId", "correctAnswerIndex", created_at, updated_at) FROM stdin;
\.
COPY public.quizes (id, question, answers, slug, "lessonId", "correctAnswerIndex", created_at, updated_at) FROM '$$PATH$$/3556.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, slug, created_at, updated_at) FROM stdin;
\.
COPY public.roles (id, name, slug, created_at, updated_at) FROM '$$PATH$$/3539.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id, title, description, "imageUrl", "userId", slug, created_at, updated_at) FROM stdin;
\.
COPY public.services (id, title, description, "imageUrl", "userId", slug, created_at, updated_at) FROM '$$PATH$$/3544.dat';

--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tags (id, name, slug, created_at, updated_at) FROM stdin;
\.
COPY public.tags (id, name, slug, created_at, updated_at) FROM '$$PATH$$/3546.dat';

--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles ("userId", "roleId") FROM stdin;
\.
COPY public.user_roles ("userId", "roleId") FROM '$$PATH$$/3547.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, username, fullname, password, "authStrategy", address, verified, created_at, updated_at) FROM stdin;
\.
COPY public.users (id, email, username, fullname, password, "authStrategy", address, verified, created_at, updated_at) FROM '$$PATH$$/3538.dat';

--
-- Name: event_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.event_tags_id_seq', 1, false);


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 8, true);


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- Name: post_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.post_tags_id_seq', 1, false);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: banners banners_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_slug_unique UNIQUE (slug);


--
-- Name: banners banners_title_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_title_unique UNIQUE (title);


--
-- Name: categories categories_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_unique UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_unique UNIQUE (slug);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: courses courses_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_slug_unique UNIQUE (slug);


--
-- Name: courses courses_title_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_title_unique UNIQUE (title);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- Name: event_tags event_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_tags
    ADD CONSTRAINT event_tags_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: events events_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_slug_unique UNIQUE (slug);


--
-- Name: events events_title_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_title_unique UNIQUE (title);


--
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- Name: lessons lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_pkey PRIMARY KEY (id);


--
-- Name: lessons lessons_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_slug_unique UNIQUE (slug);


--
-- Name: lessons lessons_title_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_title_unique UNIQUE (title);


--
-- Name: media_tbl media_tbl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_tbl
    ADD CONSTRAINT media_tbl_pkey PRIMARY KEY (id);


--
-- Name: media_tbl media_tbl_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_tbl
    ADD CONSTRAINT media_tbl_slug_unique UNIQUE (slug);


--
-- Name: opportunities opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_pkey PRIMARY KEY (id);


--
-- Name: opportunities opportunities_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opportunities
    ADD CONSTRAINT opportunities_slug_unique UNIQUE (slug);


--
-- Name: post_tags post_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_tags
    ADD CONSTRAINT post_tags_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: posts posts_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_slug_unique UNIQUE (slug);


--
-- Name: posts posts_title_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_title_unique UNIQUE (title);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects projects_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_slug_unique UNIQUE (slug);


--
-- Name: projects projects_title_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_title_unique UNIQUE (title);


--
-- Name: quizes quizes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quizes
    ADD CONSTRAINT quizes_pkey PRIMARY KEY (id);


--
-- Name: quizes quizes_question_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quizes
    ADD CONSTRAINT quizes_question_unique UNIQUE (question);


--
-- Name: quizes quizes_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quizes
    ADD CONSTRAINT quizes_slug_unique UNIQUE (slug);


--
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: roles roles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_slug_unique UNIQUE (slug);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: services services_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_slug_unique UNIQUE (slug);


--
-- Name: services services_title_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_title_unique UNIQUE (title);


--
-- Name: tags tags_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_name_unique UNIQUE (name);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_slug_unique UNIQUE (slug);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY ("userId", "roleId");


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_fullname_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_fullname_unique UNIQUE (fullname);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: banners banners_userid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_userid_foreign FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: courses courses_categoryid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_categoryid_foreign FOREIGN KEY ("categoryId") REFERENCES public.categories(id);


--
-- Name: courses courses_userid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_userid_foreign FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: enrollments enrollments_courseid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_courseid_foreign FOREIGN KEY ("courseId") REFERENCES public.courses(id);


--
-- Name: enrollments enrollments_userid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_userid_foreign FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: event_tags event_tags_eventid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_tags
    ADD CONSTRAINT event_tags_eventid_foreign FOREIGN KEY ("eventId") REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_tags event_tags_tagid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_tags
    ADD CONSTRAINT event_tags_tagid_foreign FOREIGN KEY ("tagId") REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: events events_userid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_userid_foreign FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: lessons lessons_courseid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_courseid_foreign FOREIGN KEY ("courseId") REFERENCES public.courses(id);


--
-- Name: lessons lessons_userid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_userid_foreign FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: post_tags post_tags_postid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_tags
    ADD CONSTRAINT post_tags_postid_foreign FOREIGN KEY ("postId") REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_tags post_tags_tagid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_tags
    ADD CONSTRAINT post_tags_tagid_foreign FOREIGN KEY ("tagId") REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: posts posts_authorid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_authorid_foreign FOREIGN KEY ("authorId") REFERENCES public.users(id);


--
-- Name: posts posts_categoryid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_categoryid_foreign FOREIGN KEY ("categoryId") REFERENCES public.categories(id);


--
-- Name: projects projects_userid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_userid_foreign FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: quizes quizes_lessonid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quizes
    ADD CONSTRAINT quizes_lessonid_foreign FOREIGN KEY ("lessonId") REFERENCES public.lessons(id);


--
-- Name: services services_userid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_userid_foreign FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: user_roles user_roles_roleid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_roleid_foreign FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_userid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_userid_foreign FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

